import shutil,glob,os
raw='android/app/src/main/res/raw'
os.makedirs(raw,exist_ok=True)
for f in glob.glob('sounds/*.wav'):
    shutil.copy(f,raw)
m='android/app/src/main/AndroidManifest.xml'
s=open(m,encoding='utf-8').read()
k='<uses-permission android:name="android.permission.INTERNET" />'
assert k in s
add=''.join('\n    <uses-permission android:name="android.permission.%s" />'%p for p in ('SCHEDULE_EXACT_ALARM','VIBRATE') if p not in s)
open(m,'w',encoding='utf-8').write(s.replace(k,k+add,1))
g='android/app/build.gradle'
s=open(g,encoding='utf-8').read()
s=s.replace('versionCode 1','versionCode Integer.parseInt(System.getenv("GITHUB_RUN_NUMBER") ?: "1")',1)
s=s.replace('versionName "1.0"','versionName "1.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")',1)
open(g,'w',encoding='utf-8').write(s)
shutil.copytree('icons','android/app/src/main/res',dirs_exist_ok=True)
print('prepared')
