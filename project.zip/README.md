# আমার দিন
1. এই ফোল্ডারের সব ফাইল GitHub repository-তে আপলোড করুন (.github ফোল্ডার সহ)।
2. Actions > Build APK > Run workflow।
3. শেষ হলে Releases থেকে amar-din.apk নামিয়ে ফোনে ইনস্টল করুন।
আপডেট: www/index.html বদলে Commit করুন, নতুন Release নিজে তৈরি হবে।
